﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.IO;
using System.Reflection;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace Editor_de_Grafos
{
    public partial class Editor : Form
    {
        public Editor()
        {
            InitializeComponent();            
        }

        #region Botoes de Algoritmo do Menu
        private void BtParesOrd_Click(object sender, EventArgs e)
        {
                MessageBox.Show(g.paresOrdenados(), "Mensagem", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void BtGrafoEuleriano_Click(object sender, EventArgs e)
        {
            if(g.isEuleriano())
                MessageBox.Show("O grafo e Euleriano!", "Mensagem", MessageBoxButtons.OK, MessageBoxIcon.Information);
            else
                MessageBox.Show("O grafo não e Euleriano!", "Mensagem", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void BtGrafoUnicursal_Click(object sender, EventArgs e)
        {
            if (g.isUnicursal())
                MessageBox.Show("O grafo e Unicursal!", "Mensagem", MessageBoxButtons.OK, MessageBoxIcon.Information);
            else
                MessageBox.Show("O grafo não e Unicursal!", "Mensagem", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void BtBuscaProfundidade_Click(object sender, EventArgs e)
        {
            if (g.getVerticeMarcado() != null)
            {
                g.preProfundidade(g.getVerticeMarcado().getNum());
                Refresh();
            }
            else
            {
                MessageBox.Show("Selecione um vertice!", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }

        }

        private void larguraToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (g.getVerticeMarcado() != null)
            {
                g.preLargura(g.getVerticeMarcado().getNum());
            Refresh();
            }
            else
            {
                MessageBox.Show("Selecione um vertice!", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        #endregion --------------------------------------------------------------------------------------------------

        #region botoes restantes do menu

        private void BtNovo_Click(object sender, EventArgs e)
        {
            g.limpar();
        }

        private void BtAbrir_Click(object sender, EventArgs e)
        {
            if(OPFile.ShowDialog() == DialogResult.OK)
            {
                g.abrirArquivo(OPFile.FileName);
                g.Refresh();
            }
        }

        private void BtSalvar_Click(object sender, EventArgs e)
        {
            if(SVFile.ShowDialog() == DialogResult.OK)
            {
                g.SalvarArquivo(SVFile.FileName);
            }
        }

        private void BtSair_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void BtPeso_Click(object sender, EventArgs e)
        {
            if(BtPeso.Checked)
            {
                BtPeso.Checked = false;
                g.setExibirPesos(false);

            }
            else
            {
                BtPeso.Checked = true;
                g.setExibirPesos(true);
            }
            g.Refresh();
        }

        private void BtPesoAleatorio_Click(object sender, EventArgs e)
        {
            if(BtPesoAleatorio.Checked)
            {
                BtPesoAleatorio.Checked = false;
                g.setPesosAleatorios(false);
            }
            else
            {
                BtPesoAleatorio.Checked = true;
                g.setPesosAleatorios(true);
            }
        }

        private void BtSobre_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Editor de Grafos - 2019/1\n\nDesenvolvido por:\nGuilherme Marçal\nVirgilio Borges de Oliveira\n\nAlgoritmos e Estruturas de Dados II\nFaculdade COTEMIG\nSomente para fins didáticos.", "Sobre o Editor de Grafos...", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        #endregion --------------------------------------------------------------------------------------------------

        private void completarGrafoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            
                g.completarGrafo();
                Refresh();
        }

        private void verificarSeEArvoreToolStripMenuItem_Click(object sender, EventArgs e)
        {
            
                bool retorno = g.isArvore(0);
                Refresh();
                if (retorno)
                {
                    MessageBox.Show("É árvore!", "Arvrinha", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                else
                    MessageBox.Show("Não é árvore!", "Arvrinha", MessageBoxButtons.OK, MessageBoxIcon.Information);
            
        }
        private void nCromaticoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            g.larguraprofundidade();
            g.numeroCromatico();
        }

        private void caminhoMinimoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string Titulo = "Digitar vertice 1";
            string Titulo2 = "Digitar vertice 2";

            int vertice1 = Convert.ToInt32(Interaction.InputBox(Titulo, Titulo, "1", 150, 150));
            int vertice2 = Convert.ToInt32(Interaction.InputBox(Titulo2, Titulo2, "1", 150, 150));
            vertice1 -= 1;
            vertice2 -= 1;

            g.caminhoMinimo(vertice1,vertice2);
            MessageBox.Show("Custo do vértice " + (vertice1 + 1) + " até o vértice " + (vertice2 + 1) + " é igual a: " + g.Estimativa[vertice2] + "\n" + "Caminho: " + g.Caminho + ".", "Mensagem", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void descolorirToolStripMenuItem_Click(object sender, EventArgs e)
        {
            g.larguraprofundidade();
            g.descolorir();
        }

        private void apagarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            g.apagar(0);
        }

        private void apagarArestaToolStripMenuItem_Click(object sender, EventArgs e)
        {
                string Titulo = "Digitar vertice 1";
                string Titulo2 = "Digitar vertice 2";

                int vertice1 = Convert.ToInt32(Interaction.InputBox(Titulo, Titulo, "1", 150, 150));
                int vertice2 = Convert.ToInt32(Interaction.InputBox(Titulo2, Titulo2, "1", 150, 150));
                vertice1 -= 1;
                vertice2 -= 1;
                g.apagarAre(vertice1, vertice2);
                
        }

        private void aGMToolStripMenuItem_Click(object sender, EventArgs e)
        {
            g.AGM();
            MessageBox.Show("O Custo Mínimo é: " + g.CustoMinimo, "Messagem", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
    }
}
