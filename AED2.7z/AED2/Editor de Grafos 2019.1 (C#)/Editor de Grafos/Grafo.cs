﻿using System;
using System.Drawing;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using System.Windows.Forms;

namespace Editor_de_Grafos
{
    public class Grafo : GrafoBase, iGrafo
    {
        private bool[] _visitado;
        public int CustoMinimo, QtdCor;
        public int[] Antecedente, Estimativa;
        public string Caminho;
        public bool[] visitado;
        public int EstInifitivo = 1000000000;

        public void AGM()
        {
            _visitado = new bool[getN()];

            List<int> listaVertices = new List<int>();
            listaVertices.Add(0);
            _visitado[0] = true;
            CustoMinimo = 0;

            while (listaVertices.Count < getN())        //Enquanto não tiver todos os vertices adicionados
            {
                int menorPeso = int.MaxValue, v = 0;
                Aresta menorAresta = getAresta(0, 0);
                foreach (int vertice in listaVertices)   //Pra cada vertice da lista, faça o código abaixo
                {
                    for (int i = 0; i < getN(); i++)
                    {
                        if (getAresta(vertice, i) != null && !_visitado[i])     //Se tiver aresta e o vértice I ainda não tiver sido visitado
                        {
                            if (getAresta(vertice, i).getPeso() < menorPeso)    //Compara se o peso da aresta é menor que o atual menor peso
                            {
                                menorPeso = getAresta(vertice, i).getPeso();    //Salva em menor peso o peso da aresta que for menor
                                menorAresta = getAresta(vertice, i);            //Salva a aresta com menor peso
                                v = i;                                          //Salva o vértice I que teve o menor peso com o vertice da lista
                            }
                        }
                    }
                }
                listaVertices.Add(v);       //Adiciona o vértice que teve o menor peso com o vertice da lista
                _visitado[v] = true;
                menorAresta.setCor(Color.Red);          //Colore a aresta que teve o menor peso
                getVertice(v).setCor(Color.Red);        //Colore o Vértice com menor peso
                System.Threading.Thread.Sleep(1000);
                CustoMinimo += menorAresta.getPeso();   //Soma o custo minimo
                Refresh();
            }
        }

        public void caminhoMinimo(int origem, int destino)
        {
            int proximoVertice = origem;
            Estimativa = new int[getN()];
            Antecedente = new int[getN()];
            _visitado = new bool[getN()];

            for (int i = 0; i < getN(); i++)
            {
                Estimativa[i] = int.MaxValue; //Define todas as estimativas iguais a infinito
                Antecedente[i] = -1; //Anterior negativo pois não aceita null
            }

            Estimativa[origem] = 0;
            Antecedente[origem] = origem;

            while (!_visitado[destino])     //Enquanto o destino ainda não for visitado
            {
                int menorPeso = int.MaxValue;
                for (int i = 0; i < getN(); i++)
                {
                    if (!_visitado[i] && Estimativa[i] < menorPeso)  /* Compara se o vértice I não foi visitado e se a estimativa dele
                                                                     é menor que o menor peso */
                    {
                        menorPeso = Estimativa[i];                  //Salva em menor peso a menor estimativa 
                        proximoVertice = i;                         //Salva o próximo vértice a ser visitado
                    }
                }

                _visitado[proximoVertice] = true;

                for (int k = 0; k < getN(); k++)    //Procurar os vizinhos do proximo vertice e mudar as estimativas
                {
                    if (!_visitado[k] && getAresta(proximoVertice, k) != null)  //Se ainda não foi visitado e for vizinho do proximo vertice
                    {
                        int estimativaTotal = getAresta(proximoVertice, k).getPeso() + Estimativa[proximoVertice]; //Soma o peso da aresta com a estimativa do vertice anterior 
                        if (estimativaTotal < Estimativa[k]) //Compara se a nova estimativa for menor que a atual estimativa do vértice K
                        {
                            Estimativa[k] = estimativaTotal; //Altera a estimativa do vértice K
                            Antecedente[k] = proximoVertice; //Salva o antecedente do vértice K
                        }
                    }
                }
            }

            Caminho = (destino + 1).ToString();
            for (int i = destino; i != origem;)         //Adicionar a sequencia do caminho, porém será do destino até a origem.
            {
                getVertice(i).setCor(Color.Red);
                getAresta(Antecedente[i], i).setCor(Color.Red);
                i = Antecedente[i];
                Caminho += " > " + (i + 1).ToString();  //Seta ao contrário, pois depois irá reverter pra mostrar a ordem certa
                Refresh();
            }

            //ReverseString(Caminho);
        }

        public void larguraprofundidade()
        {
            visitado = new bool[getN()];
        }

        public void numeroCromatico()
        {
            int v = 0;
            int corEscolhida;
            var listCores = new List<Color>()
            {
               Color.Red, Color.Blue, Color.Green, Color.Yellow, Color.Gold
            };
            int[] cores = new int[listCores.Count];
            visitado[v] = true;
            getVertice(v).setCor(listCores[0]);
            Refresh();
            for (v = 0; v < getN(); v++)
            {
                corEscolhida = 0;

                var coresAdjacentes = new List<Int32>();

                for (int i = 0; i < getN(); i++)
                {
                    if (getAresta(v, i) != null && visitado[i])
                    {

                        var cor = getVertice(i).getCor();

                        if (cor == Color.Red)
                        {
                            coresAdjacentes.Add(0);
                        }
                        else if (cor == Color.Blue)
                        {
                            coresAdjacentes.Add(1);
                        }
                        else if (cor == Color.Green)
                        {
                            coresAdjacentes.Add(2);
                        }
                        else if (cor == Color.Yellow)
                        {
                            coresAdjacentes.Add(3);
                        }
                        else if (cor == Color.Gold)
                        {
                            coresAdjacentes.Add(4);
                        }

                        foreach (var c in coresAdjacentes)
                        {
                            if (c != corEscolhida)
                            {
                                continue;
                            }

                            else
                            {
                                corEscolhida++;
                            }

                        }

                    }

                }

                if (corEscolhida == 0)
                {
                    cores[0]++;
                }
                else if (corEscolhida == 1)
                {
                    cores[1]++;
                }
                else if (corEscolhida == 2)
                {
                    cores[2]++;
                }
                else if (corEscolhida == 3)
                {
                    cores[3]++;
                }
                else if (corEscolhida == 4)
                {
                    cores[4]++;
                }
               

                getVertice(v).setCor(listCores[corEscolhida]);
                visitado[v] = true;
                Refresh();
            }

            int total = 0;

            foreach (var c in cores)
            {
                if (c > 0)
                {
                    total++;
                }

            }
            MessageBox.Show("Total de cores usadas: " + total, "Atenção");
        }

        public bool isArvore(int v)
        {
            int quantAresta = 0;

            for (int i = 0; i < getN(); i++)
            {
                for (int j = 0; j < getN(); j++)
                {
                    if (getAresta(i,j) != null)
                    {
                        quantAresta++;
                    }
                }
            }
            /* 
             Se o número de vértices subtraido pela quantidade de arestas dividido por 2 for igual a 1, significa
             que existe apenas um caminho entre seus vertices.       
             */
            if (getN() - quantAresta / 2 == 1)
            {
                return true;
            }
            else
                return false;
        }


        public void completarGrafo()
        {
            Random randNum = new Random();
            for (int i = 0; i < getN(); i++)
            {
                for (int j = 0; j < getN(); j++)
                {
                    if (getAresta(i, j) == null)
                    {
                        if (i != j)
                        {
                            if (getPesosAleatorios())
                            {
                                setAresta(i, j, (int)(randNum.Next(1, 100)));
                            }
                            else
                            {
                                setAresta(i, j, 1);
                            }
                        }
                    }
                }
            }
           
        }

        public bool isEuleriano()
        {
            int i;
            for (i = 0; i < getN(); i++)
            {
                if (grau(i) % 2 != 0)
                    return false;

            }
            if (getN() != 0)
                return true;
            else
                return false;
        }

        public bool isUnicursal()
        {
            int i, cont = 0;
            for (i = 0; i < getN(); i++)
            {
                if (grau(i) % 2 != 0)
                    cont++;

            }
            if (getN() != 0) { 
                if (cont == 2)
                    return true;
                else
                    return false;
            }
            else
                return false;
        }
        public void preLargura(int v)
        {
            visitado = new bool[getN()];
            largura(v);

        }
        public void largura(int v)
        {
            Fila f = new Fila(getN());
            f.enfileirar(v);
            visitado[v] = true;
            
            while (!f.vazia())
            {
                
                v = f.desenfileirar();
                for (int i = 0; i < getN(); i++)
                {
                    getVertice(v).setCor(System.Drawing.Color.Cyan);
                    if (getAresta(v, i) != null && !visitado[i])
                    {
                        getAresta(v, i).setCor(System.Drawing.Color.Magenta);
                        Refresh();
                        Thread.Sleep(500);
                        f.enfileirar(i);
                        visitado[i] = true;
                        
                    }
                }
            }
        }

        

        public String paresOrdenados()
        {
            string parod = "E = {";
            for (int i = 0; i < getN(); i++)
            {
                for (int j = 0; j < getN(); j++)
                {
                    if (getAresta(i, j) != null)
                    {
                        parod += "("+ getVertice(i).getRotulo() + "," + getVertice(j).getRotulo() + "),";
                    }
                }
            }
            parod = parod.Substring(0, parod.Length - 1);
            return parod + "}";
        }

        public void preProfundidade(int v)
        {
            visitado = new bool[getN()];
            profundidade(v);
                       
        }
        public void profundidade(int v)
        {
            visitado[v] = true;
            getVertice(v).setCor(System.Drawing.Color.Cyan);
            for (int i = 0; i < getN(); i++)
            {
                if (getAresta(v,i) != null && !visitado[i])
                {
                    getAresta(v,i).setCor(System.Drawing.Color.Magenta);
                    Refresh();
                    Thread.Sleep(500);
                    profundidade(i);
                }
            }
        }

        public void apagar(int v)
        {
            limpar();
        }

        public void apagarAre(int v1, int v2)
        {
            for (int i = 0; i < getN(); i++)
            {
                for (int j = 0; j < getN(); j++)
                {
                    if (v1 == i && v2 == j)
                    {
                        matAdj[i, j] = null;
                        matAdj[j, i] = null;
                    }
                }
            }
            Refresh();
        }

        public void descolorir()
        {
            for (int i = 0; i < getN(); i++)
            {
                for (int j = 0; j < getN(); j++)
                {
                    if (matAdj[j, i] != null)
                    {
                        getAresta(j, i).setCor(System.Drawing.Color.Black);
                        
                    }
                }
                getVertice(i).setCor(System.Drawing.Color.Black);
            }
            Refresh();
        }
    }
}
